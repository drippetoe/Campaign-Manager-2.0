#pragma once

#include <windows.h>

namespace PyWidcomm {

int str2uuid( const char *uuid_str, GUID *uuid);

};
